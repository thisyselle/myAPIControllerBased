﻿using APITemplate.IService;
using APITemplate.Service;
using Microsoft.AspNetCore.Mvc;
using TodoApi.BusinessModels;
using TodoApi.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace APITemplate
{
    [Route("api/[controller]")]
    [ApiController]
    public class TodoItemController : ControllerBase
    {
        private ITodoItemService _iservice;

        public TodoItemController(ITodoItemService iservice)
        {
            _iservice = iservice;
        }

        // POST: api/<TodoItem>/List
        [HttpPost("List")]
        public async Task<IResult> Get([FromBody]TodoItemFilter filter)
        {
            return await Task.Run(() =>
            {
                try
                {
                    var result = _iservice.GetList(filter);
                    return Results.Ok(result);
                }
                catch (Exception ex)
                {
                    return Results.Problem(ex.Message);
                }
            });
        }

        //// GET api/<TodoItemController>/5
        //[HttpGet("{id}")]
        //public TodoItem Get(int id)
        //{
        //    return "value";
        //}

        // GET api/<TodoItemController>
        [HttpPost("GetById")]
        public TodoItem Get([FromBody] TodoItemByKey filter)
        {
            return _iservice.GetById(filter);
        }

        // POST api/<TodoItemController>/Create
        [HttpPost("Create")]
        public TodoItem Post([FromBody] TodoItemCreate input)
        {
            return _iservice.Create(input);
        }

        // PUT api/<TodoItemController>/5
        [HttpPut]
        public TodoItem Put([FromBody] TodoItemUpdate input)
        {
            return _iservice.Update(input);
        }

        // DELETE api/<TodoItemController>/5
        [HttpDelete]
        public bool Delete([FromBody] TodoItemByKey input)
        {
            return _iservice.Delete(input);
        }
    }
}
