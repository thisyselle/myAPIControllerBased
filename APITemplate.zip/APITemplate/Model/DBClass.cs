﻿using System.Data.SqlClient;


namespace APITemplate
{
    public class DBClass
    {
        private static string _connectionString;

        public DBClass()
        { }
        public DBClass(string connectionString)
        {
           _connectionString = connectionString;
        }

        public SqlConnection OpenConnection()
        {
            SqlConnection _dbconn = new SqlConnection(_connectionString);
            _dbconn.Open();

            return _dbconn;
        }
        public void CloseConnection(SqlConnection _dbconn)
        {
            if (_dbconn !=null)
            {
                _dbconn.Dispose();
                _dbconn.Close();
            }
        }
    }
}
