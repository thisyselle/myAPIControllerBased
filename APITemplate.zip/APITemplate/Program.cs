using APITemplate;
using APITemplate.IRepository;
using APITemplate.IService;
using APITemplate.Repository;
using APITemplate.Service;

var builder = WebApplication.CreateBuilder(args);

// Call connection string
var connectionString = builder.Configuration.GetSection("DbConnection")["default"].ToString();

var baseclass = new DBClass(connectionString);
        
// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//builder.Services.AddDbContext<TodoItem>(options => options.UseSqlServer(connectionString));

builder.Services.AddTransient<ITodoItemService, TodoItemService>();
builder.Services.AddTransient<ITodoItemRepository, TodoItemRepository>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
