﻿namespace TodoApi.BusinessModels;

public class TodoItemByKey
{
    public long Id { get; set; }
}