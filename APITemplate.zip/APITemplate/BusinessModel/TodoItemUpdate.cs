﻿using System.ComponentModel;

namespace TodoApi.BusinessModels;

public class TodoItemUpdate
{
    public long Id { get; set; }
    [DefaultValue("")]
    public string Name { get; set; }
    [DefaultValue("")]
    public bool IsComplete { get; set; }
}