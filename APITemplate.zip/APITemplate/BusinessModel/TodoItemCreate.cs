﻿using System.ComponentModel;

namespace TodoApi.BusinessModels;

public class TodoItemCreate
{
    [DefaultValue("")]
    public string Name { get; set; } = "";
    public bool IsComplete { get; set; }
}