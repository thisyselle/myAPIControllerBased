﻿using TodoApi.BusinessModels;
using TodoApi.Models;

namespace APITemplate.IRepository
{
    public interface ITodoItemRepository
    {
        public List<TodoItem> GetListFromDb(TodoItemFilter filter);
        public TodoItem GetByIdFromDb(TodoItemByKey filter);
        public TodoItem CreateToDb(TodoItemCreate input);
        public TodoItem UpdateInDb(TodoItem oldData, TodoItemUpdate input);
        public bool DeleteInDb(TodoItemByKey input);
    }
}
