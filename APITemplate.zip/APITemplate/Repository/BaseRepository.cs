﻿using System.Data;
using System.Data.SqlClient;
using System.Reflection;

namespace APITemplate.Repository
{

    /// <summary>
    /// essentially performs the connection to the database
    /// </summary>
    public class BaseRepository : DBClass
    {
        #region PUBLIC METHODS
        /// <summary>
        /// Builds your WHERE filter in the SELECT CLAUSE
        /// </summary>
        public string BuildFilterHelper(string whereClause, string filteredField)
        {
            if (String.IsNullOrEmpty(whereClause))
                whereClause = " WHERE ";
            else
                whereClause = " AND ";

            return whereClause + filteredField;
        }
        
        /// <summary>
        /// returns the list of records and converts to a hard-defined class
        /// </summary>
        /// <typeparam name="T">the object class you specify to call this method</typeparam>
        /// <param name="query">the sql query to execute</param>
        /// <returns></returns>
        public List<T> GetList<T>(string query)
        {
            var conn = this.OpenConnection();

            SqlCommand cmd = new SqlCommand(query, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            List<T> data = ReadResults<T>(reader);

            CloseConnection(conn);
            return data;
        }

        /// <summary>
        /// returns single record converted to a hard-defined class.
        /// </summary>
        /// <typeparam name="T">the object class you specify to call this method</typeparam>
        /// <param name="query">the sql query to execute</param>
        /// <returns></returns>
        public T GetById<T>(string query)
        {
            var conn = this.OpenConnection();

            SqlCommand cmd = new SqlCommand(query, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            T data = ReadSingleResult<T>(reader);

            CloseConnection(conn);
            return data ?? default(T);
        }

        /// <summary>
        /// executes the INSERT command and returns the record in a hard-defined class
        /// </summary>
        /// <typeparam name="T">the object class you specify to call this method</typeparam>
        /// <param name="query">the sql query to execute</param>
        /// <returns></returns>
        public T Create<T>(string query)
        {
            var conn = this.OpenConnection();

            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.CommandType = System.Data.CommandType.Text;
            SqlDataReader reader = cmd.ExecuteReader();
            T data = ReadSingleResult<T>(reader);

            CloseConnection(conn);
            return data ?? default(T);
        }

        /// <summary>
        /// executes the UPDATE command and returns the affected record in a hard-defined class
        /// </summary>
        /// <typeparam name="T">the object class you specify to call this method</typeparam>
        /// <param name="query">the sql query to execute</param>
        /// <returns></returns>
        public T Update<T>(string query)
        {
            var conn = this.OpenConnection();

            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.CommandType = System.Data.CommandType.Text;
            SqlDataReader reader = cmd.ExecuteReader();
            T data = ReadSingleResult<T>(reader);

            CloseConnection(conn);
            return data ?? default(T);
        }

        /// <summary>
        /// builds and returns the SET CLAUSE of the only changed values
        /// </summary>
        /// <param name="oldData">the previous record data</param>
        /// <param name="newData">the newly input data</param>
        /// <returns></returns>
        public string UpdateSetQueryHelper(object oldData, object newData)
        {
            string updateStr = string.Empty;

            // get the properties and value of the OLD DATA RECORD
            Type oldRecordType = oldData.GetType();
            PropertyInfo[] oldproperties = oldRecordType.GetProperties();

            // get the properties and value of the NEW INPUT DATA
            Type newRecordType = newData.GetType();
            PropertyInfo[] newproperties = newRecordType.GetProperties();

            foreach (var oldProp in oldproperties)
            {
                var oldValue = oldProp.GetValue(oldData);

                //get the value from the NEW INPUT, mapping it to the same property of OLD DATA 
                var newValue = newproperties.Where(p => p.Name == oldProp.Name)?.FirstOrDefault()?.GetValue(newData);

                if (oldValue != null && newValue != null && oldValue.ToString() != newValue.ToString())
                {
                    // this is the set query where the datatype is varchar/nvarchar
                    if (oldProp.PropertyType.Name.ToLower() == "string")
                        updateStr += $"{oldProp.Name} = '{ newValue }',";

                    // this is the set query where the datatype is char
                    else if (oldProp.PropertyType.Name.ToLower() == "char")
                        updateStr += $"{oldProp.Name} = '{ newValue }',";

                    // this is the set query where the datatype is bit
                    else if (oldProp.PropertyType.Name.ToLower() == "boolean")
                        updateStr += $"{oldProp.Name} = { ((Boolean)newValue ? "1" : "0") },";

                    // this is the set query where the datatype is int/bigint/smallint etc.
                    else
                        updateStr += $"{oldProp.Name} = { newValue },";
                }
            }

            if (!String.IsNullOrWhiteSpace(updateStr))
                updateStr = updateStr.Substring(0, updateStr.Length - 1); // remove the last comma

            return updateStr;
        }

        /// <summary>
        /// executes the delete in the database
        /// </summary>
        /// <param name="query">the sql query to execute</param>
        /// <returns></returns>
        public bool Delete(string query)
        {
            var conn = this.OpenConnection();

            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.ExecuteNonQuery();

            CloseConnection(conn);
            return true;
        }
        #endregion

        #region PRIVATE METHODS
        /// <summary>
        /// converts the retrieved records to a hard-defined class based on T
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="reader"></param>
        /// <returns></returns>
        private List<T> ReadResults<T>(IDataReader reader)
        {
            Type temp = typeof(T);
            T obj = Activator.CreateInstance<T>();

            List<T> data = new List<T>();

            while (reader.Read())
            {
                foreach (var prop in temp.GetProperties())
                {
                    var propType = prop.PropertyType;
                    prop.SetValue(obj, Convert.ChangeType(reader[prop.Name].ToString(), propType));
                }
                data.Add(obj);
            }
            return data;
        }

        /// <summary>
        /// converts the retrieved single record to a hard-defined class based on T
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="reader"></param>
        /// <returns></returns>
        private T ReadSingleResult<T>(IDataReader reader)
        {
            Type temp = typeof(T);
            T obj = Activator.CreateInstance<T>();

            while (reader.Read())
            {
                foreach (var prop in temp.GetProperties())
                {
                    var propType = prop.PropertyType;
                    prop.SetValue(obj, Convert.ChangeType(reader[prop.Name].ToString(), propType));
                }
            }
            return obj;
        }
        #endregion
    }
}
