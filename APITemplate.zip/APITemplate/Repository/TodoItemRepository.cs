﻿using TodoApi.Models;
using TodoApi.BusinessModels;
using System.Reflection;
using APITemplate.IRepository;

namespace APITemplate.Repository
{
    public class TodoItemRepository : BaseRepository, ITodoItemRepository
    {        
        public List<TodoItem> GetListFromDb(TodoItemFilter filter)
       {
            // Create your query here
            string query = "SELECT * FROM [TodoItems]";
            
            // BUILD the WHERE clause depending on the passed filters. You can remove/modify this part
            string whereClause = string.Empty;
            if(filter.Id > 0)
                whereClause += BuildFilterHelper(whereClause, $"Id = { filter.Id}");

            if(!String.IsNullOrWhiteSpace(filter.Name))
                whereClause += BuildFilterHelper(whereClause, $"Name = { filter.Name }");

            if (!String.IsNullOrWhiteSpace(filter.IsComplete))
                whereClause += BuildFilterHelper(whereClause, $"IsComplete = { filter.IsComplete }");

            // base.GetList<TodoItem> is inherited from the implemented class (BaseRepository)
            return base.GetList<TodoItem>(query);
       }

        public TodoItem GetByIdFromDb(TodoItemByKey filter)
        {
            // Create your query here
            string query = $"SELECT * FROM [TodoItems] WHERE Id = { filter.Id }";

            // base.GetById<TodoItem> is inherited from the implemented class (BaseRepository)
            return base.GetById<TodoItem>(query);
        }

        public TodoItem CreateToDb(TodoItemCreate input)
        {
            // Create your query here
            string query = $@"INSERT INTO [TodoItems] (Name, IsComplete) VALUES (
                            '{ input.Name }', 
                            { (input.IsComplete ? "1" : "0") })
                              
                             SELECT * FROM [TodoItems] WHERE Id = @@IDENTITY";

            // base.Create<TodoItem> is inherited from the implemented class (BaseRepository)
            return base.Create<TodoItem>(query);
        }

        public TodoItem UpdateInDb(TodoItem oldData, TodoItemUpdate input)
        {
            // check if there are changes
            var setQuery = UpdateSetQueryHelper(oldData, input);
            if(String.IsNullOrWhiteSpace(setQuery))
                return oldData;

            // Create your query here
            string query = $@"UPDATE [TodoItems] SET { setQuery } WHERE Id = { input.Id }
                             SELECT * FROM [TodoItems] WHERE id = { input.Id }";

            return base.Update<TodoItem>(query);
        }

        public bool DeleteInDb(TodoItemByKey input)
        {
            // Create your query here
            string query = $"DELETE FROM [TodoItems] WHERE id = { input.Id }";
            return base.Delete(query);
        }
    }
}
