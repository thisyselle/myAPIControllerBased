create database APITemplate;

use APITemplate;

Create Table ToDoItems
(
	Id int IDENTITY (1,1) PRIMARY KEY,
	Name varchar(150),
	IsComplete bit DEFAULT 0
);