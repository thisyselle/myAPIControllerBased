﻿using APITemplate.IRepository;
using APITemplate.IService;
using APITemplate.Repository;
using TodoApi.BusinessModels;
using TodoApi.Models;

namespace APITemplate.Service
{
    public class TodoItemService : ITodoItemService
    {
        private readonly ITodoItemRepository _repository;

        public TodoItemService(ITodoItemRepository repository) => _repository = repository;

        public List<TodoItem> GetList(TodoItemFilter filter)
        {
            return _repository.GetListFromDb(filter);
        }

        public TodoItem GetById(TodoItemByKey filter)
        {
            // Handle any expected errors e.g. wrong input  etc.
            if (filter.Id == 0)
                throw new ArgumentException("Id is required");

            return _repository.GetByIdFromDb(filter);
        }

        public TodoItem Create(TodoItemCreate input)
        {
            // check if the record is not a duplicate

            return _repository.CreateToDb(input);
        }
        
        public TodoItem Update(TodoItemUpdate input)
        {
            // check if the record does exists
            var oldData = GetById(new() { Id = input.Id });
            if (oldData == null)
                throw new ArgumentException("Record does not exists");

            return _repository.UpdateInDb(oldData, input);
        }
        
        public bool Delete(TodoItemByKey input)
        {
            // check if the record does exists
            var oldData = GetById(new() { Id = input.Id });
            if (oldData == null)
                throw new ArgumentException("Record does not exists");

            return _repository.DeleteInDb(input);
        }
    }
}
