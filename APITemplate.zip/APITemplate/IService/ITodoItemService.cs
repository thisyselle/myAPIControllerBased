﻿using TodoApi.BusinessModels;
using TodoApi.Models;

namespace APITemplate.IService
{
    public interface ITodoItemService
    {
        public List<TodoItem> GetList(TodoItemFilter filter);
        public TodoItem GetById(TodoItemByKey filter);
        public TodoItem Create(TodoItemCreate input);
        public TodoItem Update(TodoItemUpdate input);
        public bool Delete(TodoItemByKey input);
    }
}
